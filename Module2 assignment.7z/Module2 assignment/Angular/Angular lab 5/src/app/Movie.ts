export class Movie{
    name:string;
    rating:number;
    genre:string;
}